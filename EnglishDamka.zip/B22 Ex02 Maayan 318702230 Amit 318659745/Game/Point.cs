﻿public struct Point
{
    private const int k_empty = -1;
    private int m_row;
    private int m_col;

    public int Row
    {
        get { return m_row; }
        set { m_row = value; }
    }

    public int Col
    {
        get { return m_col; }
        set { m_col = value; }
    }

    public Point(int i_row, int i_col)
    {
        m_row = i_row;
        m_col = i_col;
    }

    public Point Mean(Point other)
    {
        return new Point((Row + other.Row) / 2, (Col + other.Col) / 2);
    }
}