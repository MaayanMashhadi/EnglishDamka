﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EnglishDamka
{
    public struct UI
    {
        public static DataContainer Menu()
        {
            DataContainer output = null;
            HumanPlayer playerNumberOne = null;
            ComputerPlayer computer = null;
            HumanPlayer playerNumberTwo = null;
            string playerNumberOneName, playerNumberTwoName;
            int sizeOfBoard, userChoice;

            Console.WriteLine("Please enter your name");
            playerNumberOneName = System.Console.ReadLine();
            playerNumberOne = new HumanPlayer(playerNumberOneName);
            Console.WriteLine("Please enter the size of the board (6,8 or 10)");
            sizeOfBoard = int.Parse(System.Console.ReadLine());
            Console.WriteLine("For playing against computer press 1. \nFor two players press 2");
            userChoice = int.Parse(System.Console.ReadLine());
            if ((GameType)userChoice == GameType.againstHuman)
            {
                Console.WriteLine("Please enter the second player name ");
                playerNumberTwoName = System.Console.ReadLine();
                playerNumberTwo = new HumanPlayer(playerNumberTwoName);
            }
            else
            {
                computer = new ComputerPlayer();
            }

            Ex02.ConsoleUtils.Screen.Clear();
            output = new DataContainer(playerNumberOne, userChoice, sizeOfBoard);
            output.PlayerNumberTwo = playerNumberTwo;

            return output;
        }

        public static void PrintBoard(Board i_boardGame, string i_nameOfPlayer1, string i_nameOfPlayer2, int i_whichTurn, Point i_source, Point i_destenation)
        {
            Ex02.ConsoleUtils.Screen.Clear();
            Board.Check[,] physicalBaord = i_boardGame.BoardMartix;
            int boardLength = i_boardGame.BoardSize;
            char letter;

            Console.Write(" ");
            for (int i = 0; i < boardLength; i++)
            {
                letter = (char)('A' + (char)i);
                Console.Write("  " + letter + " ");
            }

            Console.WriteLine();
            for (int j = 0; j < (4 * boardLength) + 2; j++)
            {
                Console.Write("=");
            }

            Console.WriteLine();
            for (int i = 0; i < boardLength; i++)
            {
                letter = (char)('a' + (char)i);
                Console.Write(letter + "|");
                for (int j = 0; j < boardLength; j++)
                {
                    if (physicalBaord[i, j].IsEmpty)
                    {
                        Console.Write("   |");
                    }
                    else
                    {
                        Console.Write(" " + physicalBaord[i, j].PieceOnCheck.PlayerCharacter.ToString() + " |");
                    }
                }

                Console.WriteLine();
                for (int j = 0; j < (4 * boardLength) + 2; j++)
                {
                    Console.Write("=");
                }

                Console.WriteLine();
            }

            PrintLine(i_nameOfPlayer1, i_nameOfPlayer2, i_whichTurn, i_source, i_destenation);
        }

        public static void PrintLine(string i_nameOfPlayer1, string i_nameOfPlayer2, int i_whichTurn, Point i_source, Point i_destenation)
        {
            char colBefore, rowBefore, colAfter, rowAfter;

            colAfter = (char)((char)i_destenation.Col + 'A');
            rowAfter = (char)((char)i_destenation.Row + 'a');
            colBefore = (char)((char)i_source.Col + 'A');
            rowBefore = (char)((char)i_source.Row + 'a');

            

            
                if (i_whichTurn == 1)
                {
                    Console.WriteLine("{0}'s turn", i_nameOfPlayer1);
                }
                else if (i_whichTurn % 2 == 1)
                {
                    Console.WriteLine("{0}'s move was {1}{2}>{3}{4}", i_nameOfPlayer2, colBefore, rowBefore, colAfter, rowAfter);
                    Console.WriteLine("{0}'s turn", i_nameOfPlayer1);
                }
                else
                {
                    Console.WriteLine("{0}'s move was {1}{2}>{3}{4}", i_nameOfPlayer2, colBefore, rowBefore, colAfter, rowAfter);
                    Console.WriteLine("{0}'s turn", i_nameOfPlayer1);
                }
            

    
           
            
        }

        public static bool RequestPlayerMove(int i_boardLength, out Point o_source, out Point o_destenation)
        {
            string move = System.Console.ReadLine();

            o_source = o_destenation = new Point(-1, -1);
            while (!CheckLeaglFormatMove(move, i_boardLength))
            {
                Console.WriteLine("The move isnt written in the right format. Please enter new move");
                move = System.Console.ReadLine();
                Ex02.ConsoleUtils.Screen.Clear();
            }

            if (move.Length != 1)
            {
                o_source.Col = move[0] - 'A';
                o_source.Row = move[1] - 'a';
                o_destenation.Col = move[3] - 'A';
                o_destenation.Row = move[4] - 'a';
            }

            return move.Length == 1;
        }

        public static bool CheckLeaglFormatMove(string i_moveOfPlayer, int i_boardLength)
        {
            bool output = true;

            if (i_moveOfPlayer.Length != 5 && i_moveOfPlayer.Length != 1)
            {
                output = false;
            }
            else if (i_moveOfPlayer.Length == 1)
            {
                if (i_moveOfPlayer[0] != 'Q')
                {
                    output = false;
                }
            }
            else if (i_moveOfPlayer[2] != '>')
            {
                output = false;
            }
            else if ((i_moveOfPlayer[0] - 'A' < 0 || i_moveOfPlayer[0] - 'A' > i_boardLength - 1)
                || (i_moveOfPlayer[1] - 'a' < 0 || i_moveOfPlayer[1] - 'a' > i_boardLength - 1) ||
                (i_moveOfPlayer[3] - 'A' < 0 || i_moveOfPlayer[3] - 'A' > i_boardLength - 1) ||
                (i_moveOfPlayer[4] - 'a' < 0 || i_moveOfPlayer[4] - 'a' > i_boardLength - 1))
            {
                output = false;
            }

            return output;
        }

        public static bool IsWin(string i_name, int score)
        {
            Console.WriteLine("{0} is win. {1} scores are: {2}.\nFor continue to play, press space. For exit, press q", i_name, i_name, score);
            return char.Parse(Console.ReadLine()) == ' ';
        }

        public static bool IsTie()
        {
            Console.WriteLine("It's a tie.\nFor continue to play, press space. For exit, press q");
            return char.Parse(Console.ReadLine()) == ' ';
        }

        public static void IlegalMove()
        {
            Console.WriteLine("Illegal move. put move again");
        }
    }
}
