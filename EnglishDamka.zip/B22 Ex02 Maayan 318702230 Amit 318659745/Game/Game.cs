﻿using System;
using System.Collections.Generic;
using Ex02.ConsoleUtils;

namespace EnglishDamka
{
    public enum IdentifyPlayer
    {
        playerNumber1,
        playerNumber2,
        computer,
    }

    public enum GameType
    {
        againstHuman = 2,
        againstComputer = 1,
    }

    public class Game
    {
        private const char k_exit = 'Q';
        private Board m_board;
        private bool m_isRunning;
        private HumanPlayer m_playerNumberOne;
        private HumanPlayer m_playerNumberTwo;
        private ComputerPlayer m_computer;
        private int m_whichTurn;
        private GameType m_kindOfGame;

        public Game(DataContainer i_dataOfGame)
        {
            m_board = new Board(i_dataOfGame.SizeOfBoard);
            m_isRunning = true;
            m_kindOfGame = (GameType)i_dataOfGame.ChoiceOfUserGame;
            m_playerNumberOne = i_dataOfGame.PlayerNumberOne;
            m_playerNumberOne.PlayerCharacter = PlayerCharacter.X;
            m_whichTurn = 0;
            if (i_dataOfGame.ChoiceOfUserGame == 1)
            {
                m_computer = i_dataOfGame.Computer;
                m_computer.ComputerCharacter = PlayerCharacter.O;
                m_playerNumberTwo = null;
            }
            else
            {
                m_playerNumberTwo = i_dataOfGame.PlayerNumberTwo;
                m_playerNumberTwo.PlayerCharacter = PlayerCharacter.O;
                m_computer = null;
            }
        }

        public bool Running
        {
            get { return m_isRunning; }
            set { m_isRunning = value; }
        }

        public Board Board
        {
            get { return m_board; }
            set { m_board = value; }
        }

        public HumanPlayer PlayerNumberOne
        {
            get { return m_playerNumberOne; }
            set { m_playerNumberOne = value; }
        }

        public HumanPlayer PlayerNumberTwo
        {
            get { return m_playerNumberTwo; }
            set { m_playerNumberTwo = value; }
        }

        public ComputerPlayer Computer
        {
            get { return m_computer; }
            set { m_computer = value; }
        }

        public GameType KindOfGame
        {
            get { return m_kindOfGame; }
            set { m_kindOfGame = value; }
        }

        public int Turn
        {
            get { return m_whichTurn; }
            set { m_whichTurn = value; }
        }

        public void StartGameAgainstComputer()
        {
            int pieceIndexInList, scoreOfWinnig = 0;
            bool player1Won, computerWon, skipped, isPossibleToEat, isQuit = false, continueToPlay = false;
            Point source = new Point(-1, -1), destenation = new Point(-1, -1);

            Piece pieceToMoveForComputer;
            m_board.ResetBoard(PlayerNumberOne, null, Computer, GameType.againstComputer);
            while (Running)
            {
                CheckForAbsolutWin(out player1Won, out computerWon);
                if (!player1Won && !computerWon)
                {
                    if (isLegalMoveExistsForPlayer(IdentifyPlayer.playerNumber1))
                    {
                        Turn++;
                        UI.PrintBoard(Board, PlayerNumberOne.Name, Computer.Name, Turn, source, destenation);
                        isQuit = UI.RequestPlayerMove(m_board.BoardMartix.Length, out source, out destenation);
                        if (!isQuit)
                        {
                            while (m_board.BoardMartix[source.Row, source.Col].IsEmpty ||
                                !m_board.BoardMartix[source.Row, source.Col].PieceOnCheck.IsMoveLegalAndIsSkipped(PlayerNumberOne, destenation, out skipped)
                                || (m_board.BoardMartix[source.Row, source.Col].PieceOnCheck.PlayerCharacter != PlayerCharacter.X &&
                                m_board.BoardMartix[source.Row, source.Col].PieceOnCheck.PlayerCharacter != PlayerCharacter.K))
                            {
                               
                                
                                UI.IlegalMove();
                                UI.RequestPlayerMove(m_board.BoardMartix.Length, out source, out destenation);
                            }

                            pieceIndexInList = PlayerNumberOne.PiecesList.IndexOf(m_board.BoardMartix[source.Row, source.Col].PieceOnCheck);
                            isPossibleToEat = m_board.MovePlayer(PlayerNumberOne, pieceIndexInList, destenation, skipped, m_computer, null);
                            if (skipped)
                            {
                                while (isPossibleToEat)
                                {
                                    UI.PrintBoard(Board, PlayerNumberOne.Name, Computer.Name, Turn, source, destenation);
                                    UI.IlegalMove();
                                    UI.RequestPlayerMove(m_board.BoardMartix.Length, out source, out destenation);
                                    isPossibleToEat = m_board.MovePlayer(PlayerNumberOne, pieceIndexInList, destenation, skipped, m_computer, null);
                                }
                            }
                        }
                    }
                    else if (isLegalMoveExistsForPlayer(IdentifyPlayer.computer))
                    {
                        scoreOfWinnig = Board.CalculateWinningScore(null, Computer);
                        continueToPlay = UI.IsWin(m_computer.Name, scoreOfWinnig);
                        if (continueToPlay)
                        {
                            Restart();
                        }
                    }
                    else
                    {
                        continueToPlay = UI.IsTie();
                        if (continueToPlay)
                        {
                            Restart();
                        }
                    }
                }
                else if (player1Won)
                {
                    scoreOfWinnig = m_board.CalculateWinningScore(PlayerNumberOne, null);
                    continueToPlay = UI.IsWin(PlayerNumberOne.Name, scoreOfWinnig);
                    if (continueToPlay)
                    {
                        Restart();
                    }
                }
                else if (computerWon)
                {
                    scoreOfWinnig = m_board.CalculateWinningScore(null, Computer);
                    continueToPlay = UI.IsWin(m_computer.Name, scoreOfWinnig);
                    if (continueToPlay)
                    {
                        Restart();
                    }
                }

                if (isQuit)
                {
                    IsQuit(PlayerNumberOne);
                    break;
                }

                Turn++;
                if (!player1Won && !computerWon)
                {
                    if (isLegalMoveExistsForPlayer(IdentifyPlayer.computer))
                    {
                        UI.PrintBoard(Board, Computer.Name, PlayerNumberOne.Name, Turn, source, destenation);
                        Computer.CalculateMoveRandomly(Board, out skipped, out destenation, out pieceToMoveForComputer);
                        source = pieceToMoveForComputer.CurrentLocation;
                        pieceIndexInList = Computer.PiecesList.IndexOf(m_board.BoardMartix[source.Row, source.Col].PieceOnCheck);
                        isPossibleToEat = m_board.MoveComputer(Computer, pieceIndexInList, destenation, skipped, PlayerNumberOne);
                        System.Threading.Thread.Sleep(3000);
                        UI.PrintBoard(Board, Computer.Name, PlayerNumberOne.Name, Turn, source, destenation);
                    }
                }
            }
        }

        public void StartGameAgainstHuman()
        {
            bool isQuit = false;
            int scoreOfWinning = 0;
            bool continueToPlay = false;
            bool player1Won, player2Won, skipped, isPossibleToEat;
            int pieceIndexInList;
            Point source = new Point(-1, -1), destenation = new Point(-1, -1);
            m_board.ResetBoard(PlayerNumberOne, PlayerNumberTwo, null, GameType.againstHuman);
            while (Running)
            {
                CheckForAbsolutWin(out player1Won, out player2Won);
                if (!player1Won && !player2Won)
                {
                    if (isLegalMoveExistsForPlayer(IdentifyPlayer.playerNumber1))
                    {
                        Turn++;
                        UI.PrintBoard(Board, PlayerNumberOne.Name, PlayerNumberTwo.Name, Turn, source, destenation);
                        isQuit = UI.RequestPlayerMove(m_board.BoardMartix.Length, out source, out destenation);
                        if (!isQuit)
                        {
                            while (m_board.BoardMartix[source.Row, source.Col].IsEmpty ||
                                !m_board.BoardMartix[source.Row, source.Col].PieceOnCheck.IsMoveLegalAndIsSkipped(PlayerNumberOne, destenation, out skipped)
                                || (m_board.BoardMartix[source.Row, source.Col].PieceOnCheck.PlayerCharacter != PlayerCharacter.X &&
                                m_board.BoardMartix[source.Row, source.Col].PieceOnCheck.PlayerCharacter != PlayerCharacter.K))
                            {
                                UI.IlegalMove();
                                UI.RequestPlayerMove(m_board.BoardMartix.Length, out source, out destenation);
                            }

                            pieceIndexInList = PlayerNumberOne.PiecesList.IndexOf(m_board.BoardMartix[source.Row, source.Col].PieceOnCheck);
                            isPossibleToEat = m_board.MovePlayer(PlayerNumberOne, pieceIndexInList, destenation, skipped, null, PlayerNumberTwo);
                            if (skipped)
                            {
                                while (isPossibleToEat)
                                {
                                    UI.PrintBoard(Board, PlayerNumberOne.Name, PlayerNumberTwo.Name, Turn, source, destenation);
                                    UI.RequestPlayerMove(m_board.BoardMartix.Length, out source, out destenation);
                                    isPossibleToEat = m_board.MovePlayer(PlayerNumberOne, pieceIndexInList, destenation, skipped, null, PlayerNumberTwo);
                                }
                            }
                        }
                    }
                    else if (isLegalMoveExistsForPlayer(IdentifyPlayer.playerNumber2))
                    {
                        scoreOfWinning = m_board.CalculateWinningScore(PlayerNumberTwo, null);
                        continueToPlay = UI.IsWin(PlayerNumberTwo.Name, scoreOfWinning);
                        if (continueToPlay)
                        {
                            Restart();
                        }
                    }
                    else
                    {
                        continueToPlay = UI.IsTie();
                        if (continueToPlay)
                        {
                            Restart();
                        }
                    }
                }
                else if (player1Won)
                {
                    scoreOfWinning = m_board.CalculateWinningScore(PlayerNumberOne, null);
                    continueToPlay = UI.IsWin(PlayerNumberOne.Name, scoreOfWinning);
                    if (continueToPlay)
                    {
                        Restart();
                    }
                }
                else if (player2Won)
                {
                    scoreOfWinning = m_board.CalculateWinningScore(PlayerNumberTwo, null);
                    continueToPlay = UI.IsWin(PlayerNumberTwo.Name, scoreOfWinning);
                    if (continueToPlay)
                    {
                        Restart();
                    }
                }

                if (isQuit)
                {
                    IsQuit(PlayerNumberOne);
                }

                Turn++;
                CheckForAbsolutWin(out player1Won, out player2Won);
                if (!player1Won && !player2Won)
                {
                    if (isLegalMoveExistsForPlayer(IdentifyPlayer.playerNumber2))
                    {
                        UI.PrintBoard(Board, PlayerNumberTwo.Name, PlayerNumberOne.Name, Turn, source, destenation);
                        isQuit = UI.RequestPlayerMove(m_board.BoardMartix.Length, out source, out destenation);
                        if (!isQuit)
                        {
                            while (m_board.BoardMartix[source.Row, source.Col].IsEmpty ||
                                !m_board.BoardMartix[source.Row, source.Col].PieceOnCheck.IsMoveLegalAndIsSkipped(PlayerNumberTwo, destenation, out skipped)
                                || (m_board.BoardMartix[source.Row, source.Col].PieceOnCheck.PlayerCharacter != PlayerCharacter.O &&
                                m_board.BoardMartix[source.Row, source.Col].PieceOnCheck.PlayerCharacter != PlayerCharacter.U))
                            {
                                UI.IlegalMove();
                                UI.RequestPlayerMove(m_board.BoardMartix.Length, out source, out destenation);
                            }

                            pieceIndexInList = PlayerNumberTwo.PiecesList.IndexOf(m_board.BoardMartix[source.Row, source.Col].PieceOnCheck);
                            isPossibleToEat = m_board.MovePlayer(PlayerNumberTwo, pieceIndexInList, destenation, skipped, null, m_playerNumberOne);
                            if (skipped)
                            {
                                while (isPossibleToEat)
                                {
                                    UI.PrintBoard(Board, PlayerNumberOne.Name, PlayerNumberTwo.Name, Turn, source, destenation);
                                    UI.RequestPlayerMove(m_board.BoardMartix.Length, out source, out destenation);
                                    isPossibleToEat = m_board.MovePlayer(PlayerNumberTwo, pieceIndexInList, destenation, skipped, null, PlayerNumberOne);
                                }
                            }
                        }
                    }
                    else if (isLegalMoveExistsForPlayer(IdentifyPlayer.playerNumber1))
                    {
                        scoreOfWinning = m_board.CalculateWinningScore(PlayerNumberOne, null);
                        continueToPlay = UI.IsWin(PlayerNumberOne.Name, scoreOfWinning);
                        if (continueToPlay)
                        {
                            Restart();
                        }
                    }
                    else
                    {
                        continueToPlay = UI.IsTie();
                        if (continueToPlay)
                        {
                            Restart();
                        }
                    }
                }
                else if (player1Won)
                {
                    scoreOfWinning = m_board.CalculateWinningScore(PlayerNumberOne, null);
                    continueToPlay = UI.IsWin(PlayerNumberOne.Name, scoreOfWinning);
                    if (continueToPlay)
                    {
                        Restart();
                    }
                }
                else if (player2Won)
                {
                    scoreOfWinning = m_board.CalculateWinningScore(PlayerNumberTwo, null);
                    continueToPlay = UI.IsWin(PlayerNumberTwo.Name, scoreOfWinning);
                    if (continueToPlay)
                    {
                        Restart();
                    }
                }

                if (isQuit)
                {
                    IsQuit(PlayerNumberTwo);
                }

                Turn++;
            }
        }

        public void IsQuit(HumanPlayer i_playerQuit)
        {
            bool continueToPlay = false;
            int scoreOfWinning = 0;
            if (i_playerQuit.Equals(PlayerNumberOne))
            {
                if (KindOfGame == GameType.againstComputer)
                {
                    scoreOfWinning = m_board.CalculateWinningScore(null, Computer);
                    continueToPlay = UI.IsWin(Computer.Name, scoreOfWinning);
                }
                else
                {
                    scoreOfWinning = m_board.CalculateWinningScore(PlayerNumberTwo, null);
                    continueToPlay = UI.IsWin(PlayerNumberTwo.Name, scoreOfWinning);
                }
            }
            else
            {
                scoreOfWinning = m_board.CalculateWinningScore(PlayerNumberOne, null);
                continueToPlay = UI.IsWin(PlayerNumberOne.Name, scoreOfWinning);
            }

            m_isRunning = false;
            if (continueToPlay)
            {
                Restart();
            }
        }

        public void CheckForAbsolutWin(out bool o_player1Won, out bool o_player2Won)
        {
            o_player1Won = o_player2Won = false;
            if (isPlayerLose(IdentifyPlayer.playerNumber1))
            {
                o_player2Won = true;
            }

            if (m_kindOfGame == GameType.againstHuman)
            {
                if (isPlayerLose(IdentifyPlayer.playerNumber2))
                {
                    o_player1Won = true;
                }
            }
            else
            {
                if (isPlayerLose(IdentifyPlayer.computer))
                {
                    o_player1Won = true;
                }
            }
        }

        public void Restart()
        {
            Board.ResetBoard(PlayerNumberOne, PlayerNumberTwo, m_computer, m_kindOfGame);
            Turn = 0;
            Running = true;
        }

        private bool isLegalMoveExistsForPlayer(IdentifyPlayer i_playerType)
        {
            bool isLegalMove = false;
            List<Piece> piecesList;
            if (i_playerType == IdentifyPlayer.playerNumber1)
            {
                piecesList = PlayerNumberOne.PiecesList;
            }
            else if (i_playerType == IdentifyPlayer.playerNumber2)
            {
                piecesList = PlayerNumberTwo.PiecesList;
            }
            else
            {
                piecesList = Computer.PiecesList;
            }

            foreach (Piece piece in piecesList)
            {
                if (piece.LegalMoves.Count != 0)
                {
                    isLegalMove = true;
                    break;
                }
            }

            return isLegalMove;
        }

        private bool isPlayerLose(IdentifyPlayer i_playerType)
        {
            List<Piece> piecesList;
            if (i_playerType == IdentifyPlayer.playerNumber1)
            {
                piecesList = PlayerNumberOne.PiecesList;
            }
            else if (i_playerType == IdentifyPlayer.playerNumber2)
            {
                piecesList = PlayerNumberTwo.PiecesList;
            }
            else
            {
                piecesList = Computer.PiecesList;
            }

            return piecesList.Count == 0;
        }
    }
}
