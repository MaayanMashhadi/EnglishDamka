﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EnglishDamka
{
    public class Board
    {
        public struct Check
        {
            private Piece m_pieceOnCheck;
            private bool m_isEmpty;
            private Point m_location;

            public Piece PieceOnCheck
            {
                get { return m_pieceOnCheck; }
                set { m_pieceOnCheck = value; }
            }

            public bool IsEmpty
            {
                get { return m_isEmpty; }
                set { m_isEmpty = value; }
            }

            public Point Location
            {
                get { return m_location; }
                set { m_location = value; }
            }

            public Check(int i_row, int i_col)
            {
                m_isEmpty = true;
                m_pieceOnCheck = null;
                m_location = new Point(i_row, i_col);
            }
        }

        private readonly Check[,] m_boardMatrix;
        private int m_boardSize;

        public int BoardSize
        {
            get { return m_boardSize; }
            set { m_boardSize = value; }
        }

        public Check[,] BoardMartix
        {
            get { return m_boardMatrix; }
        }

        public Board(int i_boardSize)
        {
            m_boardSize = i_boardSize;
            m_boardMatrix = new Check[i_boardSize, i_boardSize];
            for (int i = 0; i < m_boardSize; i++)
            {
                for (int j = 0; j < m_boardSize; j++)
                {
                    m_boardMatrix[i, j] = new Check(i, j);
                }
            }
        }

        public void ResetBoard(HumanPlayer i_player1, HumanPlayer i_player2, ComputerPlayer i_computerPlayer, GameType kindOfGame)
        {
            Piece newPiece;
            int rowsForPlayer = (m_boardSize - 2) / 2;
            Point currentPosition;
            bool possibleToEat;

            for (int i = 0; i < rowsForPlayer; i++)
            {
                for (int j = 0; j < m_boardSize; j++)
                {
                    currentPosition = new Point(i, j);
                    if ((j % 2 == 1 && i % 2 == 0) || (j % 2 == 0 && i % 2 == 1))
                    {
                        newPiece = new Piece(currentPosition, PlayerCharacter.X);
                        i_player1.PiecesList.Add(newPiece);
                        putPieceOnCheck(newPiece);
                        if (i == rowsForPlayer - 1)
                        {
                            newPiece.UpdateLeagalMoves(this, out possibleToEat);
                        }
                    }
                }
            }

            for (int i = m_boardSize - 1; i > m_boardSize - rowsForPlayer - 1; i--)
            {
                for (int j = 0; j < m_boardSize; j++)
                {
                    currentPosition = new Point(i, j);
                    if ((j % 2 == 1 && i % 2 == 0) || (j % 2 == 0 && i % 2 == 1))
                    {
                        if (kindOfGame == GameType.againstHuman)
                        {
                            newPiece = new Piece(currentPosition, PlayerCharacter.O);
                            i_player2.PiecesList.Add(newPiece);
                            putPieceOnCheck(newPiece);
                        }
                        else
                        {
                            newPiece = new Piece(currentPosition, PlayerCharacter.O);
                            i_computerPlayer.PiecesList.Add(newPiece);
                            putPieceOnCheck(newPiece);
                        }

                        if (i == m_boardSize - rowsForPlayer)
                        {
                            newPiece.UpdateLeagalMoves(this, out possibleToEat);
                        }
                    }
                }
            }
        }

        private void markCheckAsEmpty(Point i_checkLocation)
        {
            m_boardMatrix[i_checkLocation.Row, i_checkLocation.Col].IsEmpty = true;
            m_boardMatrix[i_checkLocation.Row, i_checkLocation.Col].PieceOnCheck = null;
        }

        private void putPieceOnCheck(Piece i_piece)
        {
            m_boardMatrix[i_piece.CurrentLocation.Row, i_piece.CurrentLocation.Col].PieceOnCheck = i_piece;
            m_boardMatrix[i_piece.CurrentLocation.Row, i_piece.CurrentLocation.Col].IsEmpty = false;
        }

        public bool MovePlayer(HumanPlayer i_player, int i_pieceToMoveIndex, Point i_newLocation, bool i_skipped, ComputerPlayer i_computerRival, HumanPlayer i_humanRival)
        {
            bool canPlayerEat = false, canRivalEat = false;
            bool canPieceEat = false, possibleToEatAfterSkip = false;
            Piece pieceToMove = i_player.PiecesList[i_pieceToMoveIndex];
            pieceToMove.LastLocation = pieceToMove.CurrentLocation;
            pieceToMove.CurrentLocation = i_newLocation;
            putPieceOnCheck(pieceToMove);
            markCheckAsEmpty(pieceToMove.LastLocation);
            if (i_skipped)
            {
                pieceToMove.UpdateLeagalMovesAfterSkip(this, out possibleToEatAfterSkip);
                canPieceEat = possibleToEatAfterSkip;
                if (i_humanRival == null)
                {
                    Point pieceThatAteLocation = i_player.PiecesList[i_pieceToMoveIndex].CurrentLocation.Mean(i_player.PiecesList[i_pieceToMoveIndex].LastLocation);
                    i_computerRival.PiecesList.Remove(m_boardMatrix[pieceThatAteLocation.Row, pieceThatAteLocation.Col].PieceOnCheck);
                    markCheckAsEmpty(pieceThatAteLocation);
                }
                else
                {
                    Point pieceThatAteLocation = i_player.PiecesList[i_pieceToMoveIndex].CurrentLocation.Mean(i_player.PiecesList[i_pieceToMoveIndex].LastLocation);
                    i_humanRival.PiecesList.Remove(m_boardMatrix[pieceThatAteLocation.Row, pieceThatAteLocation.Col].PieceOnCheck);
                    markCheckAsEmpty(pieceThatAteLocation);
                }

                foreach (Piece piece in i_player.PiecesList)
                {
                    piece.UpdateLeagalMoves(this, out canPieceEat);
                    if (canPieceEat && piece == pieceToMove)
                    {
                        canPlayerEat = true;
                    }
                }
            }
            else
            {
                foreach (Piece piece in i_player.PiecesList)
                {
                    piece.UpdateLeagalMoves(this, out canPieceEat);
                    if (canPieceEat)
                    {
                        canPlayerEat = true;
                    }
                }
            }

            if (i_computerRival == null)
            {
                foreach (Piece piece in i_humanRival.PiecesList)
                {
                    piece.UpdateLeagalMoves(this, out canPieceEat);
                    if (canPieceEat)
                    {
                        canRivalEat = true;
                    }
                }
            }
            else
            {
                foreach (Piece piece in i_computerRival.PiecesList)
                {
                    piece.UpdateLeagalMoves(this, out canPieceEat);
                    if (canPieceEat)
                    {
                        canRivalEat = true;
                    }
                }
            }

            if (canPlayerEat)
            {
                updateLagalMovesListIfEat(i_player, null);
            }

            if (canRivalEat)
            {
                if (i_computerRival == null)
                {
                    updateLagalMovesListIfEat(i_humanRival, null);
                }
                else
                {
                    updateLagalMovesListIfEat(null, i_computerRival);
                }
            }

            return canPlayerEat;
        }

        private void updateLagalMovesListIfEat(HumanPlayer i_player, ComputerPlayer i_computerPlayer)
        {
            List<Piece> piecesList;
            if (i_player == null)
            {
                piecesList = i_computerPlayer.PiecesList;
            }
            else
            {
                piecesList = i_player.PiecesList;
            }

            List<Point> temporaryPieceLegalMoves;
            foreach (Piece piece in piecesList)
            {
                temporaryPieceLegalMoves = cloneList(piece.LegalMoves);
                foreach (Point point in temporaryPieceLegalMoves)
                {
                    if (point.Row != piece.CurrentLocation.Row + 2 && point.Row != piece.CurrentLocation.Row - 2)
                    {
                        piece.LegalMoves.Remove(point);
                    }
                }
            }
        }

        public bool MoveComputer(ComputerPlayer i_computerPlayer, int i_pieceToMoveIndex, Point i_newLocation, bool i_skipped, HumanPlayer i_rival)
        {
            bool canPlayerEat = false, canRivalEat = false;
            bool canPieceEat = false, possibleToEatAfterSkip = false;
            Piece pieceToMove = i_computerPlayer.PiecesList[i_pieceToMoveIndex];
            Point pieceThatAteLocation;

            pieceToMove.LastLocation = pieceToMove.CurrentLocation;
            pieceToMove.CurrentLocation = i_newLocation;
            markCheckAsEmpty(pieceToMove.LastLocation);
            putPieceOnCheck(pieceToMove);
            if (i_skipped)
            {
                pieceToMove.UpdateLeagalMovesAfterSkip(this, out possibleToEatAfterSkip);
                canPieceEat = possibleToEatAfterSkip;
                pieceThatAteLocation = i_computerPlayer.PiecesList[i_pieceToMoveIndex].CurrentLocation.Mean(i_computerPlayer.PiecesList[i_pieceToMoveIndex].LastLocation);
                i_rival.PiecesList.Remove(m_boardMatrix[pieceThatAteLocation.Row, pieceThatAteLocation.Col].PieceOnCheck);
                markCheckAsEmpty(pieceThatAteLocation);
                foreach (Piece piece in i_computerPlayer.PiecesList)
                {
                    piece.UpdateLeagalMoves(this, out canPieceEat);
                    if (canPieceEat && piece == pieceToMove)
                    {
                        canPlayerEat = true;
                    }
                }
            }
            else
            {
                foreach (Piece piece in i_computerPlayer.PiecesList)
                {
                    piece.UpdateLeagalMoves(this, out canPieceEat);
                    if (canPieceEat)
                    {
                        canPlayerEat = true;
                    }
                }
            }

            foreach (Piece piece in i_rival.PiecesList)
            {
                piece.UpdateLeagalMoves(this, out canPieceEat);
                if (canPieceEat)
                {
                    canRivalEat = true;
                }
            }

            if (canPlayerEat)
            {
                updateLagalMovesListIfEat(null, i_computerPlayer);
            }

            if (canRivalEat)
            {
                updateLagalMovesListIfEat(i_rival, null);
            }

            return canPlayerEat;
        }

        private List<Point> cloneList(List<Point> i_originalList)
        {
            List<Point> clone = new List<Point>();

            foreach (Point point in i_originalList)
            {
                clone.Add(point);
            }

            return clone;
        }

        public int CalculateWinningScore(HumanPlayer i_humanWin, ComputerPlayer i_computerWin)
        {
            int score = 0;

            if (i_humanWin == null)
            {
                for (int i = 0; i < m_boardSize; i++)
                {
                    for (int j = 0; j < m_boardSize; j++)
                    {
                        if (!m_boardMatrix[i, j].IsEmpty)
                        {
                            if (m_boardMatrix[i, j].PieceOnCheck.PlayerCharacter == PlayerCharacter.O)
                            {
                                score++;
                            }
                            else if (m_boardMatrix[i, j].PieceOnCheck.PlayerCharacter == PlayerCharacter.U)
                            {
                                score += 4;
                            }
                        }
                    }
                }
            }
            else if (i_humanWin.PlayerCharacter == PlayerCharacter.O)
            {
                score = 0;
                for (int i = 0; i < m_boardSize; i++)
                {
                    for (int j = 0; j < m_boardSize; j++)
                    {
                        if (!m_boardMatrix[i, j].IsEmpty)
                        {
                            if (m_boardMatrix[i, j].PieceOnCheck.PlayerCharacter == PlayerCharacter.O)
                            {
                                score++;
                            }
                            else if (m_boardMatrix[i, j].PieceOnCheck.PlayerCharacter == PlayerCharacter.U)
                            {
                                score += 4;
                            }
                        }
                    }
                }
            }
            else
            {
                for (int i = 0; i < m_boardSize; i++)
                {
                    for (int j = 0; j < m_boardSize; j++)
                    {
                        if (!m_boardMatrix[i, j].IsEmpty)
                        {
                            if (m_boardMatrix[i, j].PieceOnCheck.PlayerCharacter == PlayerCharacter.X)
                            {
                                score++;
                            }
                            else if (m_boardMatrix[i, j].PieceOnCheck.PlayerCharacter == PlayerCharacter.K)
                            {
                                score += 4;
                            }
                        }
                    }
                }
            }

            return score;
        }
    }
}
