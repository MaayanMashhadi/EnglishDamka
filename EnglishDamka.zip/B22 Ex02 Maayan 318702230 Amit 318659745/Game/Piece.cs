﻿using System.Collections.Generic;

namespace EnglishDamka
{
    public enum PlayerCharacter
    {
        X,
        K,
        O,
        U,
        Empty,
    }

    public class Piece
    {
        private PlayerCharacter m_playerCharacter;
        private Point m_currentLocation;
        private Point m_lastLocation;
        private List<Point> m_legalMoves;
        private bool m_isOnBoard;

        public PlayerCharacter PlayerCharacter
        {
            get { return m_playerCharacter; }
            set { m_playerCharacter = value; }
        }

        public Point CurrentLocation
        {
            get { return m_currentLocation; }
            set { m_currentLocation = value; }
        }

        public Point LastLocation
        {
            get { return m_lastLocation; }
            set { m_lastLocation = value; }
        }

        public List<Point> LegalMoves
        {
            get { return m_legalMoves; }
        }

        public bool isOnBoard
        {
            get { return m_isOnBoard; }
            set { m_isOnBoard = value; }
        }

        public Piece(Point i_currentLocation, PlayerCharacter i_playerCharacter = PlayerCharacter.Empty)
        {
            m_playerCharacter = i_playerCharacter;
            m_currentLocation = i_currentLocation;
            m_lastLocation = i_currentLocation;
            m_legalMoves = new List<Point>();
            m_isOnBoard = true;
        }

        public bool isKing()
        {
            return m_playerCharacter == PlayerCharacter.K || m_playerCharacter == PlayerCharacter.U;
        }

        private bool updateToKingIfNedded(int i_boardSize)
        {
            bool kimgWasMade = false;
            if (m_playerCharacter == PlayerCharacter.X)
            {
                if (CurrentLocation.Row == i_boardSize - 1)
                {
                    m_playerCharacter = PlayerCharacter.K;
                    kimgWasMade = true;
                }
            }
            else if (m_playerCharacter == PlayerCharacter.O)
            {
                if (CurrentLocation.Row == 0)
                {
                    m_playerCharacter = PlayerCharacter.U;
                    kimgWasMade = true;
                }
            }

            return kimgWasMade;
        }

        private bool updateLegalMoveUpRight(Board i_board)
        {
            bool possibleToEat = false;
            if (CurrentLocation.Row + 1 < i_board.BoardSize)
            {
                if (CurrentLocation.Col + 1 < i_board.BoardSize)
                {
                    if (i_board.BoardMartix[CurrentLocation.Row + 1, CurrentLocation.Col + 1].IsEmpty)
                    {
                        LegalMoves.Add(new Point(m_currentLocation.Row + 1, m_currentLocation.Col + 1));
                    }
                    else if (isOfRival(i_board.BoardMartix[CurrentLocation.Row + 1, CurrentLocation.Col + 1].PieceOnCheck))
                    {
                        if (CurrentLocation.Row + 2 < i_board.BoardSize && CurrentLocation.Col + 2 < i_board.BoardSize)
                        {
                            if (i_board.BoardMartix[CurrentLocation.Row + 2, CurrentLocation.Col + 2].IsEmpty)
                            {
                                LegalMoves.Add(new Point(m_currentLocation.Row + 2, m_currentLocation.Col + 2));
                                possibleToEat = true;
                            }
                        }
                    }
                }
            }

            return possibleToEat;
        }

        private bool updateLegalMoveUpLeft(Board i_board)
        {
            bool possibleToEat = false;
            if (CurrentLocation.Row + 1 < i_board.BoardSize)
            {
                if (CurrentLocation.Col > 0)
                {
                    if (i_board.BoardMartix[CurrentLocation.Row + 1, CurrentLocation.Col - 1].IsEmpty)
                    {
                        LegalMoves.Add(new Point(m_currentLocation.Row + 1, m_currentLocation.Col - 1));
                    }
                    else if (isOfRival(i_board.BoardMartix[CurrentLocation.Row + 1, CurrentLocation.Col - 1].PieceOnCheck))
                    {
                        if (CurrentLocation.Row + 2 < i_board.BoardSize && CurrentLocation.Col - 2 >= 0)
                        {
                            if (i_board.BoardMartix[CurrentLocation.Row + 2, CurrentLocation.Col - 2].IsEmpty)
                            {
                                LegalMoves.Add(new Point(m_currentLocation.Row + 2, m_currentLocation.Col - 2));
                                possibleToEat = true;
                            }
                        }
                    }
                }
            }

            return possibleToEat;
        }

        private bool updateLegalMoveDownRight(Board i_board)
        {
            bool possibleToEat = false;
            if (CurrentLocation.Row != 0)
            {
                if (CurrentLocation.Col + 1 != i_board.BoardSize)
                {
                    if (i_board.BoardMartix[CurrentLocation.Row - 1, CurrentLocation.Col + 1].IsEmpty)
                    {
                        LegalMoves.Add(new Point(m_currentLocation.Row - 1, m_currentLocation.Col + 1));
                    }
                    else if (isOfRival(i_board.BoardMartix[CurrentLocation.Row - 1, CurrentLocation.Col + 1].PieceOnCheck))
                    {
                        if (CurrentLocation.Row - 2 >= 0 && CurrentLocation.Col + 2 < i_board.BoardSize)
                        {
                            if (i_board.BoardMartix[CurrentLocation.Row - 2, CurrentLocation.Col + 2].IsEmpty)
                            {
                                LegalMoves.Add(new Point(m_currentLocation.Row - 2, m_currentLocation.Col + 2));
                                possibleToEat = true;
                            }
                        }
                    }
                }
            }

            return possibleToEat;
        }

        private bool updateLegalMoveDownLeft(Board i_board)
        {
            bool possibleToEat = false;
            if (CurrentLocation.Row != 0)
            {
                if (CurrentLocation.Col > 0)
                {
                    if (i_board.BoardMartix[CurrentLocation.Row - 1, CurrentLocation.Col - 1].IsEmpty)
                    {
                        LegalMoves.Add(new Point(m_currentLocation.Row - 1, m_currentLocation.Col - 1));
                    }
                    else if (isOfRival(i_board.BoardMartix[CurrentLocation.Row - 1, CurrentLocation.Col - 1].PieceOnCheck))
                    {
                        if (CurrentLocation.Row - 2 >= 0 && CurrentLocation.Col - 2 >= 0)
                        {
                            if (i_board.BoardMartix[CurrentLocation.Row - 2, CurrentLocation.Col - 2].IsEmpty)
                            {
                                LegalMoves.Add(new Point(m_currentLocation.Row - 2, m_currentLocation.Col - 2));
                                possibleToEat = true;
                            }
                        }
                    }
                }
            }

            return possibleToEat;
        }

        public void UpdateLeagalMoves(Board i_board, out bool o_isPossibleToEatForSide)
        {
            o_isPossibleToEatForSide = false;
            bool possibleToEatUpRight, possibleToEatUpLeft, possibleToEatDownRight, possibleToEatDownLeft = false;

            updateToKingIfNedded(i_board.BoardSize);
            LegalMoves.Clear();
            if (isKing())
            {
                possibleToEatUpRight = updateLegalMoveUpRight(i_board);
                possibleToEatUpLeft = updateLegalMoveUpLeft(i_board);
                possibleToEatDownRight = updateLegalMoveDownRight(i_board);
                possibleToEatDownLeft = updateLegalMoveDownLeft(i_board);
                o_isPossibleToEatForSide = possibleToEatUpRight || possibleToEatUpLeft || possibleToEatDownRight || possibleToEatDownLeft;
            }
            else
            {
                if (m_playerCharacter == PlayerCharacter.X)
                {
                    possibleToEatUpLeft = updateLegalMoveUpLeft(i_board);
                    possibleToEatUpRight = updateLegalMoveUpRight(i_board);
                    o_isPossibleToEatForSide = possibleToEatUpLeft || possibleToEatUpRight;
                }
                else
                {
                    possibleToEatDownRight = updateLegalMoveDownRight(i_board);
                    possibleToEatDownLeft = updateLegalMoveDownLeft(i_board);
                    o_isPossibleToEatForSide = possibleToEatDownLeft || possibleToEatDownRight;
                }
            }
        }

        public void UpdateLeagalMovesAfterSkip(Board i_board, out bool o_posiibleToEat)
        {
            o_posiibleToEat = false;

            updateToKingIfNedded(i_board.BoardSize);
            if (CurrentLocation.Row + 1 < i_board.BoardSize)
            {
                if (CurrentLocation.Col + 1 < i_board.BoardSize)
                {
                    if (!i_board.BoardMartix[CurrentLocation.Row + 1, CurrentLocation.Col + 1].IsEmpty)
                    {
                        if (i_board.BoardMartix[CurrentLocation.Row + 1, CurrentLocation.Col + 1].PieceOnCheck.PlayerCharacter != m_playerCharacter ||
                            i_board.BoardMartix[CurrentLocation.Row + 1, CurrentLocation.Col + 1].PieceOnCheck.PlayerCharacter != (PlayerCharacter)((int)m_playerCharacter + 1))
                        {
                            if (CurrentLocation.Row + 2 < i_board.BoardSize && CurrentLocation.Col + 2 < i_board.BoardSize)
                            {
                                if (i_board.BoardMartix[CurrentLocation.Row + 2, CurrentLocation.Col + 2].IsEmpty)
                                {
                                    o_posiibleToEat = true;
                                    LegalMoves.Add(new Point(CurrentLocation.Row + 2, CurrentLocation.Col + 2));
                                }
                            }
                        }
                    }

                    if (CurrentLocation.Col > 0)
                    {
                        if (!i_board.BoardMartix[CurrentLocation.Row + 1, CurrentLocation.Col - 1].IsEmpty)
                        {
                            if (i_board.BoardMartix[CurrentLocation.Row + 1, CurrentLocation.Col - 1].PieceOnCheck.PlayerCharacter != m_playerCharacter ||
                                i_board.BoardMartix[CurrentLocation.Row + 1, CurrentLocation.Col - 1].PieceOnCheck.PlayerCharacter != (PlayerCharacter)((int)m_playerCharacter + 1))
                            {
                                if (CurrentLocation.Row + 2 < i_board.BoardSize && CurrentLocation.Col - 2 >= 0)
                                {
                                    if (i_board.BoardMartix[CurrentLocation.Row + 2, CurrentLocation.Col - 2].IsEmpty)
                                    {
                                        o_posiibleToEat = true;
                                        LegalMoves.Add(new Point(CurrentLocation.Row + 2, CurrentLocation.Col - 2));
                                    }
                                }
                            }
                        }
                    }
                }

                if (isKing())
                {
                    if (CurrentLocation.Row != 0)
                    {
                        if (CurrentLocation.Col + 1 != i_board.BoardSize)
                        {
                            if (!i_board.BoardMartix[CurrentLocation.Row - 1, CurrentLocation.Col + 1].IsEmpty)
                            {
                                if (i_board.BoardMartix[CurrentLocation.Row - 1, CurrentLocation.Col + 1].PieceOnCheck.PlayerCharacter != m_playerCharacter ||
                                    i_board.BoardMartix[CurrentLocation.Row - 1, CurrentLocation.Col + 1].PieceOnCheck.PlayerCharacter != (PlayerCharacter)((int)m_playerCharacter + 1))
                                {
                                    if (CurrentLocation.Row - 2 >= 0 && CurrentLocation.Col + 2 < i_board.BoardSize)
                                    {
                                        if (i_board.BoardMartix[CurrentLocation.Row - 2, CurrentLocation.Col + 2].IsEmpty)
                                        {
                                            o_posiibleToEat = true;
                                            LegalMoves.Add(new Point(CurrentLocation.Row - 2, CurrentLocation.Col + 2));
                                        }
                                    }
                                }
                            }
                        }

                        if (CurrentLocation.Col == 0)
                        {
                            if (!i_board.BoardMartix[CurrentLocation.Row - 1, CurrentLocation.Col - 1].IsEmpty)
                            {
                                if (i_board.BoardMartix[CurrentLocation.Row - 1, CurrentLocation.Col - 1].PieceOnCheck.PlayerCharacter != m_playerCharacter ||
                                i_board.BoardMartix[CurrentLocation.Row - 1, CurrentLocation.Col - 1].PieceOnCheck.PlayerCharacter != (PlayerCharacter)((int)m_playerCharacter + 1))
                                {
                                    if (CurrentLocation.Row - 2 >= 0 && CurrentLocation.Col - 2 >= 0)
                                    {
                                        if (i_board.BoardMartix[CurrentLocation.Row - 2, CurrentLocation.Col - 2].IsEmpty)
                                        {
                                            o_posiibleToEat = true;
                                            LegalMoves.Add(new Point(CurrentLocation.Row - 2, CurrentLocation.Col - 2));
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        public bool IsMoveLegalAndIsSkipped(HumanPlayer i_player, Point i_NewLocation, out bool skipped)
        {
            bool isLegalMove = skipped = false;
            if (m_legalMoves.Contains(i_NewLocation))
            {
                isLegalMove = true;
                if ((i_player.PlayerCharacter == PlayerCharacter.X || isKing()) && CurrentLocation.Row + 2 == i_NewLocation.Row)
                {
                    skipped = true;
                }
                else if ((i_player.PlayerCharacter == PlayerCharacter.O || isKing()) && CurrentLocation.Row - 2 == i_NewLocation.Row)
                {
                    skipped = true;
                }
            }

            return isLegalMove;
        }

        public bool isOfRival(Piece i_piece)
        {
            bool isOfRival = false;
            if (PlayerCharacter == PlayerCharacter.X || PlayerCharacter == PlayerCharacter.K)
            {
                if (i_piece.PlayerCharacter == PlayerCharacter.O || i_piece.PlayerCharacter == PlayerCharacter.U)
                {
                    isOfRival = true;
                }
            }
            else
            {
                if (i_piece.PlayerCharacter == PlayerCharacter.K || i_piece.PlayerCharacter == PlayerCharacter.X)
                {
                    isOfRival = true;
                }
            }

            return isOfRival;
        }
    }
}