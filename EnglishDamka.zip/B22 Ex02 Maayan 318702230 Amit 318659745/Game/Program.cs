﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EnglishDamka
{
    public class Program
    {
        public static void Main()
        {
            DataContainer dataOfPlayers = UI.Menu();
            Game newGame = new Game(dataOfPlayers);

            if (dataOfPlayers.Computer != null)
            {
                newGame.StartGameAgainstComputer();
            }
            else
            {
                newGame.StartGameAgainstHuman();
            }
        }
    }
}
