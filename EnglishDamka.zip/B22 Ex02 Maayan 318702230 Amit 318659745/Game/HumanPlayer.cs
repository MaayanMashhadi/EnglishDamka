﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime;

namespace EnglishDamka
{
    public class HumanPlayer
    {
        private string m_mame;
        private List<Piece> m_piecesList;
        private PlayerCharacter m_playerCharacter;

        public string Name
        {
            get { return m_mame; }
            set { m_mame = value; }
        }

        public List<Piece> PiecesList
        {
            get { return m_piecesList; }
            set { m_piecesList = value; }
        }

        public PlayerCharacter PlayerCharacter
        {
            get { return m_playerCharacter; }
            set { m_playerCharacter = value; }
        }

        public HumanPlayer()
        {
            m_playerCharacter = PlayerCharacter.Empty;
            m_piecesList = new List<Piece>();
            m_mame = null;
        }

        public HumanPlayer(string i_name)
        {
            m_playerCharacter = PlayerCharacter.Empty;
            m_piecesList = new List<Piece>();
            m_mame = i_name;
        }

        public bool IsWin()
        {
            return true;
        }
    }
}
