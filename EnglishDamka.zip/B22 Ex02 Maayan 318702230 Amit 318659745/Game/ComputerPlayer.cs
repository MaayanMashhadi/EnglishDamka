﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EnglishDamka
{
    public class ComputerPlayer
    {
        private string m_name;
        private PlayerCharacter m_computerCharacter;
        private List<Piece> m_piecesList;

        public ComputerPlayer()
        {
            m_computerCharacter = PlayerCharacter.Empty;
            m_piecesList = new List<Piece>();
            m_name = "computer";
        }

        public string Name
        {
            get { return m_name; }
            set { m_name = value; }
        }

        public PlayerCharacter ComputerCharacter
        {
            get { return m_computerCharacter; }
            set { m_computerCharacter = value; }
        }

        public List<Piece> PiecesList
        {
            get { return m_piecesList; }
            set { m_piecesList = value; }
        }

        public void CalculateMoveRandomly(Board i_board, out bool skipped, out Point destenation, out Piece pieceToMove)
        {
            skipped = false;
            Random random = new Random();
            List<Point> legalNewLocations;
            List<Piece> legalPieceToMoves;
            int? potentialPieceToMoveIndexInLegalsList;

            getListOfLegalMoves(out legalNewLocations, out legalPieceToMoves);
            potentialPieceToMoveIndexInLegalsList = isPossibleToEat(legalNewLocations, legalPieceToMoves);
            if (potentialPieceToMoveIndexInLegalsList != null)
            {
                skipped = true;
            }

            int pieceToMoveIndexInLegalsList = potentialPieceToMoveIndexInLegalsList ?? random.Next(legalNewLocations.Count);
            int pieceToMoveIndex = m_piecesList.IndexOf(legalPieceToMoves[pieceToMoveIndexInLegalsList]);
            pieceToMove = m_piecesList[pieceToMoveIndex];
            destenation = legalNewLocations[pieceToMoveIndexInLegalsList];
        }

        private void getListOfLegalMoves(out List<Point> o_newLocations, out List<Piece> o_pieceToMoves)
        {
            o_newLocations = new List<Point>();
            o_pieceToMoves = new List<Piece>();

            for (int i = 0; i < m_piecesList.Count; i++)
            {
                for (int j = 0; j < m_piecesList[i].LegalMoves.Count; j++)
                {
                    o_newLocations.Add(m_piecesList[i].LegalMoves[j]);
                    o_pieceToMoves.Add(m_piecesList[i]);
                }
            }
        }

        private int? isPossibleToEat(List<Point> i_newLocations, List<Piece> i_pieceToMoves)
        {
            int? indexOfSkippablePiece = null;

            for (int i = 0; i < i_pieceToMoves.Count; i++)
            {
                if (i_pieceToMoves[i].CurrentLocation.Row + 2 == i_newLocations[i].Row || i_pieceToMoves[i].CurrentLocation.Row - 2 == i_newLocations[i].Row)
                {
                    indexOfSkippablePiece = i;
                    break;
                }
            }

            return indexOfSkippablePiece;
        }
    }
}

