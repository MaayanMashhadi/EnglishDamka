﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EnglishDamka
{
    public class DataContainer
    {
        private HumanPlayer m_playerNumberOne;
        private int m_choiceOfUserGame;
        private ComputerPlayer m_computer;
        private HumanPlayer m_playerNumberTwo;
        private int m_sizeOfBoard;

        public DataContainer(HumanPlayer i_playerNumberOne, int i_choiceOfUserGame, int i_sizeOfBoard)
        {
            m_playerNumberOne = i_playerNumberOne;
            m_choiceOfUserGame = i_choiceOfUserGame;
            m_sizeOfBoard = i_sizeOfBoard;
            if (m_choiceOfUserGame == 1)
            {
                m_computer = new ComputerPlayer();
                m_playerNumberTwo = null;
            }
            else
            {
                m_computer = null;
                m_playerNumberTwo = new HumanPlayer();
            }
        }

        public HumanPlayer PlayerNumberOne
        {
            get { return m_playerNumberOne; }
            set { m_playerNumberOne = value; }
        }

        public int ChoiceOfUserGame
        {
            get { return m_choiceOfUserGame; }
            set { m_choiceOfUserGame = value; }
        }

        public ComputerPlayer Computer
        {
            get { return m_computer; }
            set { m_computer = value; }
        }

        public HumanPlayer PlayerNumberTwo
        {
            get { return m_playerNumberTwo; }
            set { m_playerNumberTwo = value; }
        }

        public int SizeOfBoard
        {
            get { return m_sizeOfBoard; }
            set { m_sizeOfBoard = value; }
        }
    }
}
